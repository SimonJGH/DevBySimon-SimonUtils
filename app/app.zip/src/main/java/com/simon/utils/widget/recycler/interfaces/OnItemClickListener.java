package com.simon.utils.widget.recycler.interfaces;

/**
 * 点击事件
 */
public interface OnItemClickListener {

    void onItemClick(int position);

}
