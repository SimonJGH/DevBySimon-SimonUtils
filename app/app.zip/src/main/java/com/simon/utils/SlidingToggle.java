package com.simon.utils;

/**
 * Created by Simon on 2017/10/5.
 */

public interface SlidingToggle {
    public void slidingToggle(boolean toggle);
}
