package com.simon.utils.widget.recycler.interfaces;


/**
 * SwipeSwitch
 */
public interface SwipeSwitch extends Openable, Closeable {

}
